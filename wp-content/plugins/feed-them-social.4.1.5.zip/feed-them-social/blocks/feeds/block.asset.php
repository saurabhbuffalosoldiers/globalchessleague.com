<?php

return array( 'dependencies' =>
    array(
        'wp-blocks',
        'wp-block-editor',
        'wp-element',
        'wp-polyfill',
        'wp-i18n'
    ),
    'version' => '0.1'
);